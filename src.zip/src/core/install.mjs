import {TiVue} from "./polyfill-ti-vue.mjs"
//-----------------------------------
export const Tinstall = function(){
  TiVue.install()
}
//---------------------------------------
export default Tinstall

