export default {
  inheritAttrs : false,
  /////////////////////////////////////////
  props : {
    "value" : {
      type : [Object, Array],
      default : null
    }
  },
  //////////////////////////////////////////
  computed : {
    
  },
  //////////////////////////////////////////
  methods : {
    
  }
}