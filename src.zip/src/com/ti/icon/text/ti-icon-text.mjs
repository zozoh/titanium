export default {
  inheritAttrs : false,
  ///////////////////////////////////////////////////////
  props : {
    "icon" : {
      type : [String,Object],
      default : ""
    },
    "text" : {
      type : String,
      default : null
    }
  }
  ///////////////////////////////////////////////////////
}