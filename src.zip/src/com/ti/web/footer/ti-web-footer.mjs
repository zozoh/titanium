export default {
  inheritAttrs : false,
  /////////////////////////////////////////
  props : {
    "logo" : {
      type : [String, Object],
      default : "zmdi-chevron-down"
    },
    "brief" : {
      type : String,
      default : null
    },
    "copyright" : {
      type : String,
      default : null
    }
  },
  //////////////////////////////////////////
  computed : {
    //......................................
    
  }
  //////////////////////////////////////////
}