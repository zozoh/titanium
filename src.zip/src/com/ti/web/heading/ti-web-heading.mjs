export default {
  inheritAttrs : false,
  /////////////////////////////////////////
  props : {
    "title" : {
      type : String,
      default : null
    },
    "comment" : {
      type : String,
      default : null
    }
  },
  //////////////////////////////////////////
  computed : {
    
  }
  //////////////////////////////////////////
}